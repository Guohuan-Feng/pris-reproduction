"""Memory-bounded reader for the released column-oriented MP CSE JSON."""
import gzip
import json


class JSONStream:
    def __init__(self, handle):
        self.handle=handle;self.buffer='';self.offset=0;self.decoder=json.JSONDecoder();self.eof=False
    def fill(self):
        self.buffer=self.buffer[self.offset:]+self.handle.read(65536);self.offset=0
        if not self.buffer:self.eof=True
    def char(self):
        while True:
            if self.offset>=len(self.buffer):
                self.fill()
                if self.eof:raise EOFError('Unexpected JSON end')
            c=self.buffer[self.offset]
            if c.isspace():self.offset+=1;continue
            self.offset+=1;return c
    def expect(self,c):
        actual=self.char()
        if actual!=c:raise ValueError(f'Expected {c!r}, got {actual!r}')
    def value(self):
        while True:
            while self.offset<len(self.buffer) and self.buffer[self.offset].isspace():self.offset+=1
            try:
                result,end=self.decoder.raw_decode(self.buffer,self.offset);self.offset=end;return result
            except json.JSONDecodeError:
                before=len(self.buffer)-self.offset
                self.fill()
                if len(self.buffer)==before:raise


def read_id_map(path):
    with gzip.open(path,'rt',encoding='utf-8') as handle:
        stream=JSONStream(handle);stream.expect('{')
        key=stream.value();stream.expect(':')
        if key!='material_id':raise ValueError(f'Unexpected first column: {key}')
        return stream.value()


def iter_entries(path):
    with gzip.open(path,'rt',encoding='utf-8') as handle:
        stream=JSONStream(handle);stream.expect('{')
        key=stream.value();stream.expect(':')
        if key!='material_id':raise ValueError(f'Unexpected first column: {key}')
        ids=stream.value();stream.expect(',')
        key=stream.value();stream.expect(':')
        if key!='entry':raise ValueError(f'Unexpected second column: {key}')
        stream.expect('{')
        while True:
            index=stream.value();stream.expect(':');entry=stream.value()
            yield ids[index],entry,index
            delim=stream.char()
            if delim=='}':break
            if delim!=',':raise ValueError(f'Unexpected entry delimiter {delim}')
        stream.expect('}')
