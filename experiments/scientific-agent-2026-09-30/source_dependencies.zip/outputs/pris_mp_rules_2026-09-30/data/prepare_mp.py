"""Prepare a deterministic MP property-prediction cohort; never inspect test outcomes.

Uses released relaxed MP structures, so this is not a pre-DFT screening dataset.
No label-value filtering, no new DFT, no model/API calls. Stages are inspect and
features. The inspect stage verifies source energy compatibility before geometry.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import importlib.metadata
import json
import sys
import warnings
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.core import Composition, Structure
from pymatgen.entries.computed_entries import ComputedEntry, ComputedStructureEntry
from pymatgen.analysis.molecule_structure_comparator import CovalentRadius
from sklearn.model_selection import GroupShuffleSplit
from stream_cse import read_id_map, iter_entries

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
RAW=ROOT/'work/mp_rule_pilot/raw'
CSV=RAW/'2025-02-01-mp-energies.csv.gz'
CSE=RAW/'2023-02-07-mp-computed-structure-entries.json.gz'
REF=RAW/'2023-02-07-mp-elemental-reference-entries.json.gz'
SC=ROOT/'outputs/pris_crosspilot_2026-09-29/superconductivity/data/3DSC_MP.csv'
OXIDE=ROOT/'outputs/pris_crosspilot_2026-09-29/oxide/data/manifest.csv'
SAMPLING_SEED='mp-llm-20260930-v1'
OUTER_SEED=20260930
INNER_SEED=20261031
N=12000
TARGETS=['formation_energy_per_atom','energy_above_hull']
FRACTIONS=[f'comp_fraction_Z{z:03d}' for z in range(1,95)]
PROPERTIES=['Z','mass','electronegativity','row','group','atomic_radius']
COMP=['comp_n_elements','comp_entropy','comp_max_fraction']+FRACTIONS+[f'comp_{p}_{s}' for p in PROPERTIES for s in ['mean','std','min','max']]
GEO=['relaxed_min_distance_A','relaxed_min_covalent_ratio','relaxed_volume_per_atom_A3','relaxed_covalent_sphere_volume_fraction']


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,value):Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def load(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def inspect():
    df=pd.read_csv(CSV).set_index('material_id',drop=False)
    assert df.index.is_unique
    ids=read_id_map(CSE);id_values=list(ids.values())
    assert len(id_values)==len(set(id_values))
    # Read identity fields only; do not open prior target columns.
    sc=pd.read_csv(SC,skiprows=1,usecols=['material_id_2','database_id_2'])
    excluded=set(sc.material_id_2.dropna().astype(str))
    excluded.update(sc.database_id_2.dropna().astype(str).str.replace('^MP-','',regex=True))
    assert all(x.startswith(('mp-','mvc-')) for x in excluded)
    oxide_header=pd.read_csv(OXIDE,nrows=0)
    oxide_mp_cols=[c for c in oxide_header if 'material_id' in c or c=='mp_id']
    assert not oxide_mp_cols, 'New MP identity column in oxide prior; inspect exclusions before proceeding'
    pd.DataFrame({'material_id':sorted(excluded),'reason':'3DSC_MP parent used in prior superconductivity pilots'}).to_csv(OUT/'excluded_prior_mp_ids.csv',index=False)
    intersection=set(df.index)&set(id_values)
    finite=set(df.index[np.isfinite(df[TARGETS].to_numpy(float)).all(axis=1)])
    eligible=intersection&finite-excluded
    audit={'energy_table_rows':len(df),'energy_table_unique_ids':int(df.index.nunique()),'energy_table_columns':list(df.columns),
           'cse_rows':len(ids),'cse_unique_ids':len(set(id_values)),'id_intersection_count':len(intersection),
           'energy_ids_without_cse':sorted(set(df.index)-set(id_values)), 'cse_ids_without_energies':sorted(set(id_values)-set(df.index)),
           'nonfinite_needed_label_rows':int((~np.isfinite(df[TARGETS].to_numpy(float)).all(axis=1)).sum()),
           'prior_sc_unique_mp_ids':len(excluded),'prior_sc_ids_in_intersection':len(excluded&intersection),
           'prior_oxide_identity_type':'COD identifiers; no MP ID columns available for direct MP-ID exclusion',
           'prior_oxide_limitation':'No mapping from COD IDs to MP identities is available here; duplicate physical materials across providers cannot be ruled out.',
           'eligible_count':len(eligible),'requested_count':N,'sampling_seed':SAMPLING_SEED,
           'sampling_definition':'Rank exact concatenation sampling_seed + material_id by SHA256; take first 12000, no label-value or geometry-success filtering.',
           'sampling_target_value_independent':True,'source_energy_type_categories':sorted(df.energy_type.unique().tolist()),
           'energy_table_missing_counts':{c:int(v) for c,v in df.isna().sum().items()}}
    dump(OUT/'eligibility_audit.json',audit)
    print(json.dumps({'eligible_count':len(eligible),'source_intersection':len(intersection),'prior_mp_excluded':len(excluded&intersection),'energy_type_categories':audit['source_energy_type_categories']},indent=2),flush=True)
    if len(eligible)<N:raise RuntimeError('Insufficient eligible records; no automatic cohort-size adaptation')
    chosen=sorted(eligible,key=lambda mid:hashlib.sha256((SAMPLING_SEED+mid).encode()).hexdigest())[:N]
    selected=pd.DataFrame({'material_id':chosen,'sampling_rank':range(1,N+1),'selection_sha256':[hashlib.sha256((SAMPLING_SEED+mid).encode()).hexdigest() for mid in chosen]})
    selected.to_csv(OUT/'selected_ids.csv',index=False)
    selected_set=set(chosen)
    with gzip.open(REF,'rt',encoding='utf-8') as f:refs=json.load(f)
    e_refs={el:ComputedEntry.from_dict(entry).energy_per_atom for el,entry in refs.items()}
    compatibility=[];selected_metadata=[];found=set();errors=[]
    composition_checks={'entry_vs_structure_checked':0,'entry_vs_structure_mismatches':[], 'csv_formula_checked':0,'csv_formula_missing':0,'csv_formula_mismatches':[]}
    eligible_compatibility={'checked_rows':0,'max_abs_energy_difference_eV_per_atom':0.,'max_abs_formation_difference_eV_per_atom':0.,'energy_mismatch_rows':0,'formation_mismatch_rows':0,'run_type_disagreements':0,'errors':[]}
    with gzip.open(OUT/'selected_entries.jsonl.gz','wt',encoding='utf-8') as target:
        for mid,entry,index in iter_entries(CSE):
            if mid in eligible:
                try:
                    ce=ComputedEntry.from_dict(entry)
                    comp=ce.composition.element_composition
                    ref_energy=sum(float(amount)*e_refs[el] for el,amount in comp.get_el_amt_dict().items())/comp.num_atoms
                    source_row=df.loc[mid]
                    energy_diff=float(ce.energy_per_atom)-float(source_row.energy_per_atom)
                    formation_diff=float(ce.energy_per_atom)-ref_energy-float(source_row.formation_energy_per_atom)
                    eligible_compatibility['checked_rows']+=1
                    eligible_compatibility['max_abs_energy_difference_eV_per_atom']=max(eligible_compatibility['max_abs_energy_difference_eV_per_atom'],abs(energy_diff))
                    eligible_compatibility['max_abs_formation_difference_eV_per_atom']=max(eligible_compatibility['max_abs_formation_difference_eV_per_atom'],abs(formation_diff))
                    eligible_compatibility['energy_mismatch_rows']+=int(abs(energy_diff)>1e-6)
                    eligible_compatibility['formation_mismatch_rows']+=int(abs(formation_diff)>1e-6)
                    eligible_compatibility['run_type_disagreements']+=int(str(ce.parameters.get('run_type'))!=source_row.energy_type)
                except Exception as exc:eligible_compatibility['errors'].append({'material_id':mid,'error':f'{type(exc).__name__}: {exc}'})
            if mid not in selected_set:continue
            try:
                cse=ComputedStructureEntry.from_dict(entry)
                comp=cse.composition.element_composition
                composition_checks['entry_vs_structure_checked']+=1
                if not Composition(entry['composition']).almost_equals(cse.structure.composition,rtol=1e-8,atol=1e-8):
                    composition_checks['entry_vs_structure_mismatches'].append(mid)
                source_formula=df.loc[mid,'formula']
                if pd.isna(source_formula):composition_checks['csv_formula_missing']+=1
                else:
                    composition_checks['csv_formula_checked']+=1
                    if not Composition(source_formula).fractional_composition.almost_equals(comp.fractional_composition,rtol=1e-8,atol=1e-8):
                        composition_checks['csv_formula_mismatches'].append(mid)
                assert cse.data.get('material_id',mid)==mid
                assert cse.entry_id==mid or str(cse.entry_id).startswith(mid+'-')
                reference_energy=sum(float(amount)*e_refs[el] for el,amount in comp.get_el_amt_dict().items())/comp.num_atoms
                epa=float(cse.energy_per_atom)
                reconstructed=epa-reference_energy
                row=df.loc[mid]
                run_type=str(cse.parameters.get('run_type'))
                compatibility.append({'material_id':mid,'source_energy_type':row.energy_type,'cse_run_type':run_type,
                    'cse_corrected_energy_per_atom':epa,'csv_energy_per_atom':float(row.energy_per_atom),
                    'energy_difference_eV_per_atom':epa-float(row.energy_per_atom),
                    'reconstructed_formation_energy_per_atom':reconstructed,'csv_formation_energy_per_atom':float(row.formation_energy_per_atom),
                    'formation_difference_eV_per_atom':reconstructed-float(row.formation_energy_per_atom),
                    'correction_eV_per_atom':float(cse.correction/comp.num_atoms),
                    'correction_adjustment_names':' | '.join(str(a.name) for a in cse.energy_adjustments),
                    'entry_id':cse.entry_id})
                selected_metadata.append({'material_id':mid,'formula':comp.reduced_formula,
                    'chemical_system':'-'.join(sorted(e.symbol for e in comp.elements)),
                    'composition_signature':json.dumps(sorted((e.symbol,round(comp.get_atomic_fraction(e),10)) for e in comp.elements),separators=(',',':')),
                    'energy_type':row.energy_type,**{label:float(row[label]) for label in TARGETS}})
                target.write(json.dumps({'material_id':mid,'entry':entry},separators=(',',':'))+'\n')
                found.add(mid)
            except Exception as exc:errors.append({'material_id':mid,'error':f'{type(exc).__name__}: {exc}'})
    comparisons=pd.DataFrame(compatibility).set_index('material_id').loc[[m for m in chosen if m in found]].reset_index()
    comparisons.to_csv(OUT/'energy_compatibility_rows.csv.gz',index=False)
    metadata=pd.DataFrame(selected_metadata).set_index('material_id').loc[[m for m in chosen if m in found]].reset_index()
    metadata.to_csv(OUT/'selected_metadata.csv.gz',index=False)
    tolerance=1e-6
    compatibility_audit={'selected_count':N,'retrieved_count':len(found),'entry_errors':errors,'missing_selected_ids':sorted(selected_set-found),
        'all_eligible_source_compatibility':eligible_compatibility,
        'composition_consistency':composition_checks,
        'energy_comparison_tolerance_eV_per_atom':tolerance,
        'maximum_absolute_corrected_energy_difference_eV_per_atom':float(comparisons.energy_difference_eV_per_atom.abs().max()),
        'maximum_absolute_formation_energy_difference_eV_per_atom':float(comparisons.formation_difference_eV_per_atom.abs().max()),
        'corrected_energy_mismatches_above_tolerance':int((comparisons.energy_difference_eV_per_atom.abs()>tolerance).sum()),
        'formation_energy_mismatches_above_tolerance':int((comparisons.formation_difference_eV_per_atom.abs()>tolerance).sum()),
        'run_type_disagreements':int((comparisons.source_energy_type!=comparisons.cse_run_type).sum()),
        'energy_type_categories':sorted(comparisons.source_energy_type.unique().tolist()),
        'correction_adjustment_names':sorted(set(name for text in comparisons.correction_adjustment_names for name in text.split(' | ') if name)),
        'scope':'Source compatibility checks before modeling/splitting; no per-split target summaries, no held-out predictive results.',
        'source_definition':'Released MP GGA/GGA+U thermo formation energy and nonnegative native own-hull energy; not signed decomposition_enthalpy and not WBM fixed-reference hull.'}
    dump(OUT/'energy_compatibility_audit.json',compatibility_audit)
    print(json.dumps(compatibility_audit,indent=2),flush=True)
    if errors or selected_set!=found:raise RuntimeError('Selected entry failures; no silent replacement')
    if composition_checks['entry_vs_structure_mismatches'] or composition_checks['csv_formula_mismatches']:raise RuntimeError('Composition mismatch: review before feature extraction')
    if any(compatibility_audit[k] for k in ['corrected_energy_mismatches_above_tolerance','formation_energy_mismatches_above_tolerance','run_type_disagreements']):
        raise RuntimeError('Energy compatibility mismatch: review before feature extraction; do not target-filter records')
    if any(eligible_compatibility[k] for k in ['energy_mismatch_rows','formation_mismatch_rows','run_type_disagreements','errors']):
        raise RuntimeError('Eligible pool source compatibility mismatch: review; do not cherry-pick matching rows')


def composition_features(comp):
    elems=list(comp.elements);w=np.array([comp.get_atomic_fraction(e) for e in elems])
    out={'comp_n_elements':len(elems),'comp_entropy':float(-sum(w*np.log(w))),'comp_max_fraction':float(max(w))}
    out.update({name:0. for name in FRACTIONS})
    for e in elems:
        if e.Z>94:raise ValueError('Element outside frozen Z1..94 whitelist')
        out[f'comp_fraction_Z{e.Z:03d}']=comp.get_atomic_fraction(e)
    props={'Z':[float(e.Z) for e in elems],'mass':[float(e.atomic_mass) for e in elems],
        'electronegativity':[float(e.X) if e.X is not None else np.nan for e in elems],
        'row':[float(e.row) for e in elems],'group':[float(e.group) for e in elems],
        'atomic_radius':[float(e.atomic_radius) if e.atomic_radius is not None else np.nan for e in elems]}
    for key,values in props.items():
        a=np.array(values);ok=np.isfinite(a)
        if not ok.any():
            for stat in ['mean','std','min','max']:out[f'comp_{key}_{stat}']=np.nan
        else:
            ww=w[ok]/sum(w[ok]);aa=a[ok];mean=float(sum(ww*aa))
            out.update({f'comp_{key}_mean':mean,f'comp_{key}_std':float(np.sqrt(sum(ww*(aa-mean)**2))),f'comp_{key}_min':float(min(aa)),f'comp_{key}_max':float(max(aa))})
    return out


def geometry(s):
    # Four intensive/basis-invariant outputs from prior WBM geometry helper.
    if not s.is_ordered:raise ValueError('Disordered structure: no radius assignment attempted')
    radii=np.array([CovalentRadius.radius[site.specie.symbol] for site in s])
    radius=max(3.5,2*radii.max())
    for _ in range(8):
        central,other,images,distances=s.get_neighbor_list(radius,exclude_self=True)
        if not len(distances):radius*=2;continue
        normalized=distances/(radii[central]+radii[other]);qmin=normalized.min()
        if radius>=qmin*2*radii.max()+1e-6:break
        radius=qmin*2*radii.max()+1e-4
    else:raise ValueError('Neighbor search did not certify normalized minimum')
    return {'relaxed_min_distance_A':float(distances.min()),'relaxed_min_covalent_ratio':float(qmin),
            'relaxed_volume_per_atom_A3':float(s.volume/len(s)),
            'relaxed_covalent_sphere_volume_fraction':float((4*np.pi/3*(radii**3).sum())/s.volume)}


def schema():
    definitions={}
    for name in COMP:
        if name in FRACTIONS:unit='dimensionless atomic fraction';meaning=f'Atomic fraction of atomic number {int(name[-3:])}; absent elements are zero.'
        elif name=='comp_n_elements':unit='count';meaning='Number of distinct elements, independent of cell replication.'
        elif name=='comp_entropy':unit='nats';meaning='Composition mixing entropy -sum(x*ln x), no thermodynamic temperature factor.'
        elif name=='comp_max_fraction':unit='dimensionless atomic fraction';meaning='Largest elemental atomic fraction.'
        else:
            prop,stat=name[5:].rsplit('_',1)
            unit={'Z':'dimensionless atomic number','mass':'atomic mass unit','electronegativity':'dimensionless Pauling','row':'dimensionless periodic-table row','group':'dimensionless periodic-table group','atomic_radius':'angstrom'}[prop]
            meaning=f'{stat} of tabulated elemental {prop}; mean/std use atomic fractions; std is population standard deviation. Missing elemental values are omitted and remaining weights renormalized; if none are known the output is missing.'
        definitions[name]={'unit':unit,'definition':meaning,'source':'composition of supplied relaxed structure'}
    definitions.update({
      'relaxed_min_distance_A':{'unit':'angstrom','definition':'Minimum periodic inter-site distance including nonzero self-images, excluding the same site at zero image.','source':'DFT-relaxed structure'},
      'relaxed_min_covalent_ratio':{'unit':'dimensionless','definition':'Minimum periodic d_ij/(r_cov_i+r_cov_j), using pymatgen CovalentRadius table; radius-based proxy, not a bond-validity verdict.','source':'DFT-relaxed structure'},
      'relaxed_volume_per_atom_A3':{'unit':'angstrom^3/atom','definition':'DFT-relaxed cell volume divided by number of sites in an ordered structure.','source':'DFT-relaxed structure'},
      'relaxed_covalent_sphere_volume_fraction':{'unit':'dimensionless','definition':'Sum of tabulated elemental covalent sphere volumes divided by cell volume. Spheres can overlap; not literal nonoverlapping packing fraction.','source':'DFT-relaxed structure'}})
    return {'task':'mp_property_prediction','features':COMP+GEO,'composition_features':COMP,'geometry_features':GEO,
       'definitions':definitions,'feature_count':len(COMP+GEO),'id_column':'material_id','formula_column':'formula',
       'group_column':'chemical_system','composition_signature_column':'composition_signature','split_column':'split',
       'split_roles':['train','validation','test'],'targets':{'formation_energy_per_atom':{'unit':'eV/atom','definition':'Released MP GGA/GGA+U corrected formation energy relative to elemental references'},
       'energy_above_hull':{'unit':'eV/atom','definition':'Released nonnegative native MP energy above its own hull; not signed decomposition_enthalpy','positive_class_threshold':1e-8,'positive_class_operator':'<='}},
       'excluded_inputs':['energy_per_atom','formation_energy_per_atom','energy_above_hull','decomposition_enthalpy','energy_type','material_id','chemical_system','composition_signature','spacegroup/prototype metadata','raw cell site count and shape'],
       'imputation':'No feature imputation in preparation; downstream imputers must be fit on their fitting partition only.','weights':'Uniform rows',
       'interpretation':'Geometry already uses DFT-relaxed structures: property prediction, not a DFT-free discovery screening demonstration.'}


def features():
    audit=load(OUT/'energy_compatibility_audit.json')
    if any(audit[k] for k in ['entry_errors','missing_selected_ids','corrected_energy_mismatches_above_tolerance','formation_energy_mismatches_above_tolerance','run_type_disagreements']):
        raise RuntimeError('Unresolved source compatibility issue')
    if any(audit['all_eligible_source_compatibility'][k] for k in ['energy_mismatch_rows','formation_mismatch_rows','run_type_disagreements','errors']):raise RuntimeError('Unresolved eligible-pool energy issue')
    if audit['composition_consistency']['entry_vs_structure_mismatches'] or audit['composition_consistency']['csv_formula_mismatches']:raise RuntimeError('Unresolved composition issue')
    metadata=pd.read_csv(OUT/'selected_metadata.csv.gz').set_index('material_id')
    selected=pd.read_csv(OUT/'selected_ids.csv')
    rows=[];errors=[]
    with gzip.open(OUT/'selected_entries.jsonl.gz','rt',encoding='utf-8') as f:
        for count,line in enumerate(f,1):
            item=json.loads(line);mid=item['material_id']
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                s=Structure.from_dict(item['entry']['structure'])
                row={'material_id':mid,**metadata.loc[mid].to_dict(),**composition_features(s.composition.element_composition)}
                try:row.update(geometry(s))
                except Exception as exc:
                    errors.append({'material_id':mid,'error':f'{type(exc).__name__}: {exc}'})
                    row.update({key:np.nan for key in GEO})
            rows.append(row)
            if count%2000==0:print(f'Feature rows {count}/{N}; geometry errors {len(errors)}',flush=True)
    df=pd.DataFrame(rows).set_index('material_id').loc[selected.material_id].reset_index()
    assert len(df)==N and df.material_id.is_unique
    assert np.isfinite(df[TARGETS]).all().all()
    assert np.allclose(df[FRACTIONS].sum(axis=1),1)
    assert not set(df.material_id)&set(pd.read_csv(OUT/'excluded_prior_mp_ids.csv').material_id)
    group=df.chemical_system
    outer,test=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=OUTER_SEED).split(df,groups=group))
    tr,va=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=INNER_SEED).split(df.iloc[outer],groups=group.iloc[outer]))
    parts={'train':outer[tr],'validation':outer[va],'test':test}
    splits=df[['material_id','chemical_system','composition_signature']].copy();splits['split']=''
    for role,index in parts.items():splits.loc[index,'split']=role
    system_sets={role:set(group.iloc[index]) for role,index in parts.items()}
    signature_sets={role:set(df.composition_signature.iloc[index]) for role,index in parts.items()}
    overlap={f'{a}__{b}':{'chemical_systems':len(system_sets[a]&system_sets[b]),'composition_signatures':len(signature_sets[a]&signature_sets[b])} for a,b in [('train','validation'),('train','test'),('validation','test')]}
    assert all(v==0 for item in overlap.values() for v in item.values())
    df.to_csv(OUT/'features.csv.gz',index=False)
    splits.to_csv(OUT/'split_assignments.csv',index=False)
    dump(OUT/'feature_schema.json',schema());dump(OUT/'feature_errors.json',errors)
    split_audit={'n_rows':len(df),'n_chemical_systems':int(group.nunique()),'group_definition':'Exact alphabetical element set, independently of stoichiometry or prototype',
       'outer_seed':OUTER_SEED,'inner_seed':INNER_SEED,'outer_test_group_fraction':.2,'validation_fraction_of_outer_train_groups':.2,
       'split_counts':{role:{'rows':len(index),'chemical_systems':len(system_sets[role])} for role,index in parts.items()},
       'overlap':overlap,'selected_prior_mp_id_overlap':0,'geometry_failed_rows':len(errors),
       'feature_missing_counts':{c:int(v) for c,v in df[COMP+GEO].isna().sum().items() if v},
       'test_outcome_summary':'Not calculated. No per-split label prevalence, mean, distribution or prediction was inspected.',
       'feature_error_policy':'Retain original deterministic IDs and missing geometry values; no replacement or geometry-success selection.'}
    dump(OUT/'split_audit.json',split_audit)
    provenance=load(OUT/'download_provenance.json')
    provenance.update({'selection_seed':SAMPLING_SEED,'selection_size':N,'source_energy_table':'2025-02-01-mp-energies.csv.gz','source_structure_snapshot':'2023-02-07-mp-computed-structure-entries.json.gz',
       'energy_compatibility':'All selected CSE corrected energies and formation energies reconstructed with supplied elemental references checked against released CSV at 1e-6 eV/atom.',
       'composition_extractor_origin':'Adapted composition_features from prior superconductivity/run_pilot.py, extending fixed elemental vocabulary to Z1..94.',
       'geometry_extractor_origin':'Four invariant outputs copied from prior wbm/run_wbm_pilot.py geometry function; here applied to MP DFT-relaxed structures.',
       'source_extractor_hashes':{'composition':sha(ROOT/'outputs/pris_crosspilot_2026-09-29/superconductivity/run_pilot.py'),'geometry':sha(ROOT/'outputs/pris_crosspilot_2026-09-29/wbm/run_wbm_pilot.py')},
       'source_exclusion_lookup_hashes':{'3DSC_MP.csv':sha(SC),'oxide_manifest.csv':sha(OXIDE)},
       'output_hashes':{p.name:sha(p) for p in [OUT/'selected_ids.csv',OUT/'features.csv.gz',OUT/'split_assignments.csv',OUT/'feature_schema.json',OUT/'prepare_mp.py',OUT/'stream_cse.py']},
       'package_versions':{p:importlib.metadata.version(p) for p in ['numpy','pandas','pymatgen','scikit-learn']},
       'limitations':['These are already DFT-relaxed structures; this experiment cannot establish pre-DFT screening performance.','No fresh DFT, model, or Materials Project API calls were made.','Native MP hull labels describe thermodynamic stability under this reference/calculation convention, not synthesizability.','Old superconductivity MP parent IDs excluded; old oxide COD-to-MP correspondence unavailable.','Chemical-system grouping prevents exact composition/system overlap across this split but cannot eliminate all shared physical families or pretrained-model familiarity.']})
    dump(OUT/'source_provenance.json',provenance)
    print(json.dumps(split_audit,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['inspect','features']);args=parser.parse_args()
    inspect() if args.stage=='inspect' else features()
